# Actualización Bambú · datos al 17-oct-2026

Sube solo estos archivos; reemplazan a los existentes con la misma ruta.

## bambu-cima/ (repositorio de Bambú CIMA)
- app/btc_real.js, app/eth_real.js: bases de datos BTC y ETH al 17-oct, con el valor diario del Supply in Profit reconstruido del 5 al 17-oct
- app/history.js: fecha de datos
- app/supplyProfit.jsx, app/sectionsMarket.jsx, index.html: gráfica de Supply in Profit del corto en On-chain+

## bambu-2/ (repositorio de Bambú 2.0)
- bambu2/data.js: datos al 17-oct
- bambu2/supply.js: panel Supply in Profit llega al último día, recuadro de valores al pasar el mouse

## Cómo subirlos
1. Abre el repositorio en github.com → Add file → Upload files.
2. Arrastra el contenido de la carpeta correspondiente (con sus subcarpetas, para que cada archivo caiga en su ruta).
3. Commit changes. GitHub Pages se actualiza en 1–2 minutos.
